# mm-nrm
Multi matching neural ranking model
